# Fire Cube Lightbar Controller
Kodi addon for control of the Fire TV Cube LEDs and LED animations.
